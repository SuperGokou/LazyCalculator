//
//  calcApp.swift
//  calc
//
//  Created by Ming Xia on 2/17/22.
//

import SwiftUI

@main
struct calcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
